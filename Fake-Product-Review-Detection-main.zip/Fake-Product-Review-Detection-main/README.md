# Fake-Product-Review-Detection
Official Repo of my work for Fake Product Review Detection

# Packages
1. streamlit
2. nltk
3. pandas
4. numpy
5. scikit-learn

# Process
1. Run main.ipynb it generates svm.sav file
2. And, then run - streamlit run app.py


